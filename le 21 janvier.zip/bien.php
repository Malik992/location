<!DOCTYPE html>
<html>
<head>
    <title>inscription des biens </title>

    <!-- link bootstrap -->

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>

</head>
<body style="background-image: url('img.jpg'); background-size: cover;">

    <div class="container">
        <br>
        <center>
            <div id="connexion" style="width: 600px;">
            <div class="card" style="background: white;">
                <div class="card-body">
                    <a href=""><i class="fa fa-home fa-5x" aria-hidden="true" style="float: left; color: white;"></i></a><br>
                    <center><h1 class="text-primary">Page bien</h1><br></center>
                    <form method="POST" action="">
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label"><h5>Numero de piece</h5></label>
                            <input type="text" class="form-control col-lg-8" name="numpiece"  placeholder="Entrez votre Numero de piece">
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label"><h5>Profil</h5></label>
                            <input type="text" class="form-control col-lg-8" name="profil"  placeholder="Entrez votre profil">
                        </div>
                        <input type="submit" name="seach" class="btn btn-primary" value="recherche"><br><br>
                      
                            <a href="connexion.php" style="color: white;">Se connecter</a>
                        </center> 
                        <center>
                    <?php 
                        
                        require 'index.php';

                        use location\das\utilisateur;
                        use location\das\gestionProprietaire;

                        $bdd = new PDO('mysql:host=localhost;dbname=bdlocation', 'root', 'malik92');
                        $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);

                        extract($_POST);
                        if (isset($seach)) {
                            if ($numpiece=="" || $Profil =="") {
                                echo "<span class='alert alert-danger'>Veuillez saisir tous les champs</span>";
                            }
                            else{
                                $uti= new utilisateur(null, $nomcomplet, $login, $password, $Profil,$etatuser);
                                $gestion = new gestionUtilisateur($bdd);
                                $gestion->add($uti);
                                echo "<span class='alert alert-secondary'>Utilisateur ajouté avec succés</span>";

                            }
                        }
                    ?>
                </center>
                <br><br>.                    
                        
                    </form>
                </div>
                </div>
        </div>
        </center>
    </div>

</body>
</html>
