<?php 
	
	namespace location\das
	{

		use \PDO;

		// classe Propriétaire

		class Proprietaire{
			private $idpro;
			private $numpiece;
			private $nompro;
			private $tel;

			public function __construct($idpro, $numpiece, $nompro, $tel){
				$this->id = $idpro;
				$this->numpiece = $numpiece;
				$this->nompro= $nompro;
				$this->tel = $tel;
			}

			// accesseurs de le classe propriétaire

			public function numpiece(){
				return $this->numpiece;
			}

			public function nompro(){
				return $this->nompro;
			}

		
			public function tel(){
				return $this->tel;
			}

		}

		// Classe qui gère les propriétaires

		class gestionProprietaire{

			private $bdd;

			// constructeur de la classe

			public function __construct(PDO $bdd){
				$this->bdd = $bdd;
			}

			public function add(Proprietaire  $pro){
				$sql = $this->bdd->prepare("INSERT INTO proprietaire VALUES (null, :numpiece, :nompro, :tel)");
				$sql->execute(array(
					'numpiece' => $pro->numpiece(),
					'nompro' => $pro->nompro(),
					'tel' => $pro->tel()
				));
			}

			// methode permet de modifier le tel d'un propriétaire

			public function update($idpro, $tel){
				$this->bdd->exec('UPDATE proprietaire SET tel="'.$tel.'" WHERE idpro='.$idpro);
			}

			//rechercher un propriétaire à travers son CNI

			public function find($numpiece){
				$sql = $this->bdd->query("SELECT * FROM proprietaire WHERE numpiece = '".$numpiece."'");
				return $sql;
			}

			//méthode lister qui retourne la liste des propriétaire

			public function lister(){
				$sql = $this->bdd->query("SELECT * FROM proprietaire");
				return $sql;
			}
		}

		//Classe bien 

		class Bien{
			private $idbien;
			private $nombien;
			private $adressbien;
			private $montanloc;
			private $commission;
			private $idtype;
			private $idpro;
			private $etatbien;
			
			// constructeur de la classe

			public function __construct($idbien,$nombien,$adressbien,$montanloc,$commission,$idtype,$idpro,$etatbien){
				$this->idbien = $idbien;
				$this->nombien = $nombien;
				$this->adressbien = $adressbien;
				$this->montanloc = $montanloc;
				$this->commission = $commission;
				$this->idtype = $idtype;
				$this->idpro = $idpro;
				$this->etatbien = $etatbien;
			}

			// accesseurs de la classe

			public function idbien(){
				return $this->idbien;
			}

			public function nombien(){
				return $this->nombien;
			}

			public function adressbien(){
				return $this->adressbien;
			}

			public function montanloc(){
				return $this->montanloc;
			}

			public function commission(){
				return $this->commission;
			}

			public function idtype(){
				return $this->idtype;
			}
			public function idpro(){
				return $this->idpro;
			}

			public function etatbien(){
				return $this->etatbien;
			}

			

			public function addbien()
			{
				$this->bdd = new PDO('mysql:host=localhost;dbname=bdlocation;charset=utf8', 'root', 'malik92');
				array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION);
				proprietaire::$this->getConnection();
				$trouv=proprietaire::find();
				if($trouv==1)
				{
					$sql="INSERT INTO Bien VALUES (null,:nomBien,:adresse,:montantLoc,:commission,:idtypeBien,:idPro)";
					 $req=$this->bdd->prepare($sql);
					 $donnees=$req->execute(array(
						 'nombien'=>$this->nomBien,
						 'adresse'=> $this->adresse,
						 'montantLoc' =>$this->montantLoc,
						 'commission'=>$this->commission
					 ));
					 return $donnees;
			
				}
				else{
					proprietaire::addProprietaire();
					function addBien()
					{
						$this->getConnexion();
					   $sql = "INSERT INTO Bien VALUES (null,?,?,?,?,?,?)";
						$req = $this->bdd->prepare($sql);
						$data = $req->execute(
							array('nombien'=>$this->nom,
							'adresse'=>$this->adresse,
							'montantLoc'=>$this->montantLoc,
							'commission'=>$this->commission,
						));
						return $data;
					}
				}
			
			}
			// methode lister par etat
			//créer un objet Proprietaire
			function findtype()
			{
				$this->getConnexion();
				$req=('SELECT nombien FROM Bien WHERE idType==idBien');
				return $req;
			}
			
			function update()
			{
				$this->getConnexion();
				$req=$this->bdd->prepare("UPDATE Bien SET nomBien='$nombien' WHERE $trouv=proprietaire::find()");
				$donnes=$req->execute(array('nombien=$this->nom'));
				return $donnees;
			}
			
			function findBien()
			{
				$this->getConnexion();
				$req=$this->bdd->query("SELECT nomBien FROM Bien WHERE $trouv=proprietaire::find()");
			return $req;
			}
			
			
			function lister()
			{
				$this->getConnexion();
				$req=$this->bdd->query('SELECT nomBien FROM bien');
				return $req;
			}
			//créer un objet TypeBien

		}


		// classe qui gère les bien

		class gestionBien{
			private $bdd;

			// constructeur de la classe

			public function __construct(PDO $bdd){
				$this->bdd  = $bdd;
			}

			//methode qui enregistre un bien et son propiétaire s'il n'existe pas

			public function add($nombien, $adressbien, $montanloc, $commission, $nompro, $numpiece, $tel, $etatbien){

				$idtype="";
				$idpro="";

				// Vérification du propriétaire

				$verifpro = $this->bdd->query("SELECT * FROM proprietaire WHERE numpiece='".$numpiece."' AND nompro='".$nompro."'");

				if ($res=$verifpro->fetch()) {
					$idtype=$req['idpro'];
				}else{

					$this->bdd->exec("INSERT INTO proprietaire VALUES (null, '".$numpiece."', '".$nompro."', '".$tel."')");
					$idtype=$this->bdd->query("SELECT * FROM proprietaire WHERE numpiece='".$numpiece."' AND nompro='".$nompro."'");
					if ($resultat=$idtype->fetch()) {
						$idtype=$resultat['idpro'];
					}
				}

				// Vérification du type de bien 3:03

				$verifbien = $this->bdd->query("SELECT * FROM typeBien WHERE Nom='".$etatbien."'");

				if ($res=$verifbien->fetch()) {
					$idpro=$res['id'];
				}else{
					$this->bdd->exec("INSERT INTO typeBien VALUES (null, '".$etatbien."')");
					$idb = $this->bdd->query("SELECT * FROM typeBien WHERE Nom='".$etatbien."'");
					if ($res=$idb->fetch()) {
						$idpro=$res['id'];
					}

				}

				$sql = $this->bdd->prepare("INSERT INTO Bien VALUES (null, :Nom, :adressbien, :montanloc, :commission, :idTypeBien, :idproprietaire)");
				$sql->execute(array(
					'Nom' => $nombien,
					'adressbien' => $adressbien,
					'montanloc' => $montanloc,
					'commission' => $commission,
					'idTypeBien' => $idpro,
					'idProprietaire' => $idP
				));
			}

			//methode update qui permet de modifier les données des bien mais le propriétaire n'est pas modifiable

			// public function update(Bien $b, ){

			// }

			//methode find qui permet de retrouver un bien à travers son nom

			public function find($Nom){
				$sql = $this->bdd->query("SELECT * FROM Bien WHERE Nom = '".$Nom."'");
				return $sql;
			}

			//methode lister qui retourne la liste des biens

			public function lister(){
				$sql = $this->bdd->query("SELECT b.Nom as 	nombien, adressbien, montanloc, commission, p.Nom as nompro, tb.Nom as etatbien, numPiece FROM Bien as b, Proprietaire as p, typeBien as tb WHERE p.id=idProprietaire AND tb.id = idTypeBien");
				return $sql;
			}

			//methode listerByType qui retourne tous les biens d'un type donnée qui prend en paramètre l'id

			public function listerByType($idType){
				$sql = $this->bdd->query("SELECT * FROM Bien WHERE idTypeBien =".$idType);
				return $sql;
			}
		}




		// Classe type bien

		class TypeBien{

			private $id;
			private $Nom;


			//methode add qui permet d'enregister un bien.

			//methode lister qui liste les types de bien.

			//methode findById qui retourne un type de bien à travers son id.
		}
		class utilisateur{
		
			private $iduser;
			private $nomcomplet;
			private $login;
			private $password;
			private $profil;
            private $etatuser;
			// constructeur de la classe

			public function __construct($iduser, $nomcomplet, $login, $password, $profil,$etatuser){
				$this->iduser = $iduser;
				$this->nomcomplet = $nomcomplet;
				$this->login = $login;
				$this->password = $password;
				$this->profil = $profil;
				$this->etatuser = $etatuser;

			}

			// accesseurs de le classe

			public function iduser(){
				return $this->iduser;
			}

			public function nomcomplet(){
				return $this->nomcomplet;
			}

			public function login(){
				return $this->login;
			}

			public function password(){
				return $this->password;
			}

			public function profil(){
				return $this->profil;
			}
			public function etatuser(){
				return $this->etatuser;
			}
		}

		// classe qui gère les utilisateur

		class gestionUtilisateur{

			private $bdd;

			// constructeur de la classe

			public function __construct(PDO $bdd){
				$this->bdd  = $bdd;
			}

			//methode add qui enregistre un utilisateur avec l'etat -1(pas encore activé).

			public function add(utilisateur $uti){
				$sql = $this->bdd-> prepare("INSERT INTO utilisateur VALUES (null, :nomcomplet, :login, :password, :profil, :etatuser)");
				$sql -> execute(array(
					'nomcomplet' => $uti->nomcomplet(),
					'login' => $uti->login(),
					'password' => $uti->password(),
					'profil' => $uti->profil(),
					'etatuser' => $uti->etatuser()
				));
			}

			//methode activer/desactiver qui permet d'activer ou de désactiver un utilisateur.

			public function changeEtat($iduser){
				$sql = $this->bdd->query("SELECT * FROM utilisateur WHERE iduser = ".$iduser);
				if ($res = $sql->fetch()) {
					$etatt;
					if($res['etat'] == -1 || $res['etat'] == 0){   //si l'utilisateur n'est pas encore activé oubien s'il est désactivé
						$etatt = 1;
					}
					else   //s'il est activé, on le désactive
						$etatt = 0;

					$this->bdd->execute("UPDATE utilisateur SET etat = ".$etatt." WHERE iduser=".$iduser);
				}
			}

			public function supprimer($iduser){
				$this->bdd->execute("DELETE FROM utilisateur WHERE iduser=".$iduser);
			}

			//methode listerUser qui retourne la liste des utilisateur.

			public function lister(){
				$sql = $this->bdd->query("SELECT * FROM utilisateur ORDER BY id DESC");
				return $sql;
			}

			//methode logon qui permet de se loger qui aura en paramétre (login et mot de passe) et qui retourne l'utilisateur.

			public function connexion($login, $password){
				$sql = $this->bdd->query("SELECT * FROM utilisateur WHERE login='".$login."' AND password='".$password."'");
				return $sql;
			}

			//methode changepwd permettant à un utilisateur de changer un mot de passe.

			public function changepw($iduser, $password){
				$sql = $this->bdd->query("SELECT * FROM utilisateur WHERE iduser= ".$iduser);
				if ($res = $sql->fetch()) {
					$this->bdd->execute("UPDATE utilisateur SET password = '".$password."' WHERE iduser=".$iduser);
				}
				
			}

		}
	}

	

?>
